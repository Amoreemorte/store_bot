package repository

type ModeratorRepositoryConfig struct {
	MigrateEnable bool
}

type ModeratorStateRepositoryConfig struct {
	MigrateEnable bool
}

type CollectionRepositoryConfig struct {
	MigrateEnable bool
}
